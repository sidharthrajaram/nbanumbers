from setuptools import setup

setup(name='nbanumbers',
      version='0.3',
      description='nba stats retrieval package',
      url='http://github.com/sidharthrajaram/nbanumbers',
      author='Sid Rajaram',
      author_email='tmzturtle@gmail.com',
      license='MIT',
      packages=['nbanumbers'],
      install_requires=['google-api-python-client','pandas','urllib.request','bs4','requests','urllib.request','io','numpy','re'],
      zip_safe=False)

